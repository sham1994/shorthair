package com.jblearning.duckhuntingv3;

import java.util.TimerTask;

public class GameTimerTask extends TimerTask {
  private Game game;
  private  shoot dgame;
  private GameView gameView;
  
  public GameTimerTask( GameView view ) {
    gameView = view;
    game = view.getGame( );
    game.startDuckFromRightTopHalf( );
    //
    dgame = view.getshoot();
    dgame.startDuckFromRightTopHalf( );
    //
  }
  
  public void run( ) {
    game.moveDuck( );
    dgame.moveDuck();
    if( game.bulletOffScreen( ) )
      game.loadBullet( );
    else if( game.isBulletFired( ) )
      game.moveBullet( );
    if( game.duckOffScreen( )  ) {
      game.setDuckShot( false );

      game.startDuckFromRightTopHalf( );

    }
    else if(dgame.duckOffScreen()){
      dgame.setDuckShot(false);
      dgame.startDuckFromRightTopHalf();
    }

    else if( game.duckHit( ) ) {
      game.setDuckShot( true );
      dgame.setDuckShot(true);
      ( ( MainActivity ) gameView.getContext( ) ).playHitSound();
      game.loadBullet( );
    }
    else if(dgame.duckHit()){
      dgame.setDuckShot(true);
      ( ( MainActivity ) gameView.getContext( ) ).playHitSound( );
      game.loadBullet( );

    }
    gameView.postInvalidate( );
  }

}
